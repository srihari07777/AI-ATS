const express = require("express");
const fileUpload = require("express-fileupload");
const pdfParse = require("pdf-parse");
const natural = require("natural");
const Fuse = require("fuse.js");
const cors = require("cors");

const app = express();
app.use(fileUpload());
app.use(cors());
app.use(express.json());
app.use(express.static("public")); // Serve frontend files

// Function to Extract Text from PDF
async function extractTextFromPDF(pdfBuffer) {
    const data = await pdfParse(pdfBuffer);
    return data.text;
}

// Function to Extract Keywords Using TF-IDF
function getImportantKeywords(text) {
    const tfidf = new natural.TfIdf();
    tfidf.addDocument(text);
    const keywords = [];
    tfidf.listTerms(0).forEach(item => {
        keywords.push(item.term);
    });
    return keywords.slice(0, 10); 
}

// Function for Fuzzy Matching
function fuzzyMatch(resumeKeywords, jobDescription) {
    const fuse = new Fuse(resumeKeywords, { includeScore: true, threshold: 0.3 });
    return fuse.search(jobDescription).map(result => result.item);
}

// Function to Compute Cosine Similarity
function cosineSimilarity(text1, text2) {
    const tokenizer = new natural.WordTokenizer();
    const words1 = tokenizer.tokenize(text1.toLowerCase());
    const words2 = tokenizer.tokenize(text2.toLowerCase());
    
    const wordsSet = new Set([...words1, ...words2]);
    const vector1 = [];
    const vector2 = [];
    
    wordsSet.forEach(word => {
        vector1.push(words1.filter(w => w === word).length);
        vector2.push(words2.filter(w => w === word).length);
    });
    
    const dotProduct = vector1.reduce((sum, val, i) => sum + val * vector2[i], 0);
    const magnitude1 = Math.sqrt(vector1.reduce((sum, val) => sum + val ** 2, 0));
    const magnitude2 = Math.sqrt(vector2.reduce((sum, val) => sum + val ** 2, 0));
    
    return dotProduct / (magnitude1 * magnitude2);
}

// API to Handle File Upload & Processing
app.post("/upload", async (req, res) => {
    if (!req.files || !req.files.resume) {
        return res.status(400).send("No file uploaded.");
    }
    
    const resumeText = await extractTextFromPDF(req.files.resume.data);
    const jobDescription = req.body.jobDescription;
    
    const resumeKeywords = getImportantKeywords(resumeText);
    const fuzzyMatches = fuzzyMatch(resumeKeywords, jobDescription);
    const similarityScore = cosineSimilarity(resumeText, jobDescription);
    
    res.json({
        keywords: resumeKeywords,
        fuzzyMatches: fuzzyMatches,
        similarityScore: similarityScore.toFixed(2)
    });
});

// Start Server
app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});
