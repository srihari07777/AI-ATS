// Function to show file name after uploading
function displayFileName() {
    const resumeInput = document.getElementById("resume");
    const fileName = document.getElementById("file-name");
    
    if (resumeInput.files.length > 0) {
        fileName.textContent = "Uploaded: " + resumeInput.files[0].name;
    } else {
        fileName.textContent = "No file chosen";
    }
}

// Function to handle file upload and comparison
async function uploadFile() {
    const resume = document.getElementById("resume").files[0];
    const jobDescription = document.getElementById("jobDescription").value;

    if (!resume || !jobDescription) {
        alert("Please upload a resume and enter a job description.");
        return;
    }

    document.getElementById("loading").classList.remove("hidden");
    const formData = new FormData();
    formData.append("resume", resume);
    formData.append("jobDescription", jobDescription);
    
    const response = await fetch("http://localhost:3000/upload", {
        method: "POST",
        body: formData,
    });
    const result = await response.json();
    
    document.getElementById("loading").classList.add("hidden");
    document.getElementById("resultContainer").classList.remove("hidden");
    
    document.getElementById("score").textContent = (result.similarityScore * 100).toFixed(2) + "%";
    document.getElementById("keywords").textContent = result.keywords.join(", ");
    document.getElementById("fuzzyMatches").textContent = result.fuzzyMatches.join(", ");
}
